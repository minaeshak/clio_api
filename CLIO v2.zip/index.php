
<h1>Welcome to CLIO APP</h1>

<form method="post">
<input type="submit" name="Auth" value="Authorize"> </br></br>
Enter Display Number for Matter
</br></br><textarea name="display_id" rows="8" cols="80"></textarea>  </br>
<input type="submit" name="Complete" value="Mark As Completed" />

</form>

<?php
require_once('functions.php');
$REQ = 'https://eu.app.clio.com/oauth/authorize?client_id=b8StZo2glWArzI0t1jALiKvSjHGXhmIzvJjtP6pE&response_type=code&redirect_uri=http://localhost/CLIO/Token.php';


if (isset($_POST['Auth']))
{//file_get_contents($REQ);
//ssfile_get_contents($REQ);
header('Location:' .$REQ);


}
/////////////////////////////////////////



//$URL = "https://eu.app.clio.com/api/v4/matters.json?fields=id,display_number,client{id,name},status{pending}";
//$URL = "https://eu.app.clio.com/api/v4/matters.json?fields=id,display_number,client{id,name},task_template_list_instances";
if(isset($_POST['Complete']))
{

  $ids = explode("\n",str_replace("\r","",$_POST['display_id']));
  //print_r ($ids);


  foreach ($ids As $id){
    $id = "$id";

  $URL = "https://eu.app.clio.com/api/v4/matters.json?fields=id,display_number&query=".$id;
  $result_matter = json_decode(send_request($URL,'GET'),true);
  //echo $result_matter['data']['0']['id'];

  $matter_id=$result_matter['data']['0']['id'];

$URL = "https://eu.app.clio.com/api/v4/tasks.json?fields=id,matter{id,display_number},name&matter_id=".$matter_id."&query=Prepare%20Documentation%20Abm";
$result = json_decode(send_request($URL,'GET'),true);
$task_id = $result['data']['0']['id'];

  //echo $task_id; //question ? is it possible to have 1 matter with multi prepare document tasks



$URL = "https://eu.app.clio.com/api/v4/tasks/".$task_id.".json";
$result = json_decode(send_patch_request($URL),true);

$URL2 = "https://eu.app.clio.com/api/v4/tasks/".$task_id.".json?fields=status";
$result = json_decode(send_request($URL2,'GET'),true);


$status=$result['data']['status'];



//$URL = "https://eu.app.clio.com/api/v4/tasks.json?fields=matter{display_number}&ids[]=430973";

//echo $result['data'];
//echo jsonToTable($result['data']);
echo "</br><b>Prepare Documentation Abm</b> Task for matter <b>".$id. " </b>is now <b>".$status."</b>";
}
}


else
{echo "Please Enter Display Number";}
?>
